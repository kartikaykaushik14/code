# Copyright (c) Facebook, Inc. and its affiliates.
__all__ = ["BaseTrainer"]

from .base_trainer import BaseTrainer
