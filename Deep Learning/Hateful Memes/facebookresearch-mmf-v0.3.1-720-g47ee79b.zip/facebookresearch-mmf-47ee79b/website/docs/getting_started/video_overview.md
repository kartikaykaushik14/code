---
id: video_overview
title: Video overview
sidebar_label: Video overview
---

<div align="center">
  <img width="80%" src="https://i.imgur.com/Ud2MaDz.gif"/>
</div>
