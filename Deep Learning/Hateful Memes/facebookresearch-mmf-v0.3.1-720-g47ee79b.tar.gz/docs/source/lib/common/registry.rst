common.registry
===============

.. automodule:: mmf.common.registry
  :members:
